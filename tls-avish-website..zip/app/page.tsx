export default function Page() {
  return (
    <main>
      <section style={{ padding: "80px 20px", textAlign: "center", background: "linear-gradient(to right, black, gold)" }}>
        <h1 style={{ fontSize: "48px", marginBottom: "20px" }}>TLS-AVISH BEAUTY & NAIL SPA</h1>
        <p>Luxury Beauty. Advanced Technology. Premium Experience.</p>
        <a href="#" style={{ display: "inline-block", marginTop: "20px", padding: "10px 20px", background: "white", color: "black", borderRadius: "10px" }}>
          Book Appointment
        </a>
      </section>

      <section style={{ padding: "60px 20px", textAlign: "center" }}>
        <h2>Our Services</h2>
        <p>Pedicure • Manicure • Laser Hair Removal • Facials • Waxing • Hair • Lashes</p>
      </section>

      <section style={{ padding: "60px 20px", textAlign: "center", background: "#111" }}>
        <h2>Visit Us</h2>
        <iframe
          src="https://www.google.com/maps?q=7311+101+Ave+NW+Edmonton+AB&output=embed"
          style={{ width: "100%", height: "300px", border: 0 }}
        ></iframe>
      </section>

      <section style={{ padding: "60px 20px", textAlign: "center" }}>
        <h2>Contact</h2>
        <p>(866) 931-3959</p>
        <p>info@tlsavishbeautyspa.com</p>
        <p>7311 101 Ave NW, Edmonton AB</p>
      </section>
    </main>
  );
}