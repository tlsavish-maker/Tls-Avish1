export const metadata = {
  title: "TLS-AVISH Beauty & Nail Spa",
  description: "Luxury Beauty. Advanced Technology. Premium Experience.",
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body style={{ margin: 0, fontFamily: "Arial, sans-serif", background: "#000", color: "#fff" }}>
        {children}
      </body>
    </html>
  );
}